def subtract_nums(num1, num2):
    """This method will be used to subtract num2 from num1

        :param int num1: The first number
        :param int num2: The second number

        :returns: The answer

        :rtype: int
    """
    answer = num2 - num1
    return answer
